package com.example.micha.newsapp;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class DisasterAdapter extends ArrayAdapter {
    public DisasterAdapter(Activity context, ArrayList<Disasters> disasters) {
        super(context, 0, disasters);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listViewItem = convertView;
        if (listViewItem == null) {
            listViewItem = LayoutInflater.from(getContext()).inflate(R.layout.list_layout, parent, false);
        }
        Disasters recentDisaster = (Disasters) getItem(position);

        TextView titleText = (TextView) listViewItem.findViewById(R.id.title);
        titleText.setText(recentDisaster.getTitle());

        TextView sectionText = (TextView) listViewItem.findViewById(R.id.section);
        sectionText.setText(recentDisaster.getSection());

//        TextView contributorText = (TextView) listViewItem.findViewById(R.id.text2);
//        contributorText.setText(recentDisaster.getContributor());

        TextView pubDate = (TextView) listViewItem.findViewById(R.id.pub_date);
        pubDate.setText(recentDisaster.getDate());
        return listViewItem;
    }
}


//        Date dateObject = new Date(recentDisaster.getTimePublished());
//
//        // Find the TextView with view ID date
//        TextView dateView = (TextView) listViewItem.findViewById(R.id.text3);
//
//        // Format the date string (i.e. "Mar 3, 1984")
//        String formattedDate = dateView(timeObject);
//
//        // Display the date of the current earthquake in that TextView
//        dateView.setText(formattedDate);
//
//        // Find the TextView with view ID time
//        TextView timeView = (TextView) listViewItem.findViewById(R.id.time);
//        // Format the time string (i.e. "4:30PM")
//        String formattedTime = formatTime(dateObject);
//        // Display the time of the current earthquake in that TextView
//        timeView.setText(formattedTime);
//        return listViewItem;
//    }
//
//    private String formatTime(Date dateObject) {
//        SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy");
//        return dateFormat.format(dateObject);
//    }

