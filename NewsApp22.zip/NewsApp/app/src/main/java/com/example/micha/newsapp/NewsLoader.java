package com.example.micha.newsapp;

import android.content.AsyncTaskLoader;
import android.content.Context;
import android.util.Log;

import org.json.JSONException;

import java.util.List;

public class NewsLoader extends AsyncTaskLoader<List<News>> {

    private static final String LOG_TAG = NewsLoader.class.getName();

    private String mUrl;

    public NewsLoader(Context context, String url) {
        super(context);
        mUrl = url;
    }

    @Override
    protected void onStartLoading() {
        Log.i(LOG_TAG, "ONSTARTLOADING~^~^~^~^~^~^~");
        forceLoad();

    }

    @Override
    public List<News> loadInBackground() {
        Log.i(LOG_TAG, "LOADINBACKGROUND~*~*~*~*~*~~*~*~*~*~");
        if (mUrl == null) {
            return null;
        }
        List<News> newsList = null;
        try {
            return DataQuery.fetchNewsData(mUrl);
        } catch (JSONException e) {
            Log.e(LOG_TAG, "why wont you work!!!#$#$#$#", e);
        }
        return newsList;
    }
}
