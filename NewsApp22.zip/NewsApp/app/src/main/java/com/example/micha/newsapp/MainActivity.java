package com.example.micha.newsapp;

import android.app.LoaderManager;
import android.content.Context;
import android.content.Intent;
import android.content.Loader;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<List<News>> {

    public static final String LOG_TAG = MainActivity.class.getName();
    private static final int NEWS_LOADER_ID = 1;
    private static final String GUARDIAN_REQUEST_URL = "https://content.guardianapis.com/search?from-date=2018-01-07&q=extreme%20weather%2C%20natural%20disasters%2C%20hurricane%2C%20typhoon%2C%20earthquake%2C%20sinkhole%2C%20landslide%2C%20disease%2C%20climate%2C%20flood%2C%20tornado%2C%20wildfire%2C%20extinction%2C%20pollution%2C%20deforestation%2C%20magnetic%20pole%20shift%2C%20air%20quality%2C%20uv%20index&api-key=f45ca4ef-8077-4746-9a98-021e29ad633a";
    Context context;
    private NewsAdapter mAdapter;
    private TextView mEmptyStateTextView;



//extreme weather, natural disasters, typhoon, hurricane, volcano, earthquake, sinkhole, landslide, nuclear war, disease, flood, pollution, tornado, extinction, deforestation, air quality, magnetic pole shift, niburu, martial law
//new search query terms...


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ListView newsList = (ListView) findViewById(R.id.list);

        mEmptyStateTextView = (TextView) findViewById(R.id.empty_view);
        newsList.setEmptyView(mEmptyStateTextView);

        mAdapter = new NewsAdapter(this, new ArrayList<News>());

        newsList.setAdapter(mAdapter);

        newsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                News news = (News) mAdapter.getItem(position);

                Uri storyUri = Uri.parse(news.getUrl());

                Intent webIntent = new Intent(Intent.ACTION_VIEW, storyUri);

                startActivity(webIntent);
            }
        });

        ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();

        if (networkInfo != null && networkInfo.isConnected()) {
            LoaderManager loaderManager = getLoaderManager();
            loaderManager.initLoader(NEWS_LOADER_ID, null, this);
        } else {
            View loadingIndicator = findViewById(R.id.loadingIndicator);
            loadingIndicator.setVisibility(View.GONE);
            mEmptyStateTextView.setText("Check Network Connection!");
        }

    }
        @Override public Loader<List<News>> onCreateLoader ( int i, Bundle bundle){
            Log.i(LOG_TAG, "TEST: On Create Load called...~+~+~+~+~");

            return new NewsLoader(this, GUARDIAN_REQUEST_URL);
        }

        @Override public void onLoadFinished (Loader < List < News >> loader, List < News > newsList){
            mEmptyStateTextView.setText("News Stories not Available.");
            View loadingIndicator = findViewById(R.id.loadingIndicator);
            loadingIndicator.setVisibility(View.GONE);
            Log.i(LOG_TAG, "TEST: On Load Finished called...~@~@~@~@~");
            mAdapter.clear();

            if (newsList != null && !newsList.isEmpty()) {
                mAdapter.addAll(newsList);
            }

        }

        @Override public void onLoaderReset (Loader < List < News >> loader) {
            mAdapter.clear();

        }
    }

