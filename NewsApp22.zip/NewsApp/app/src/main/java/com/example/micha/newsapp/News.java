package com.example.micha.newsapp;

public class News {
    private String mSectionName;
    private String mPubDate;
    private String mWebTitle;


//    private String mContributor;


    private String mUrl;

    public News(String section, String date, String title) {
        mSectionName = section;
        mPubDate = date;
        mWebTitle = title;


    }

    public String getSection() {
        return mSectionName;
    }

    public String getDate() {
        return mPubDate;
    }

    public String getTitle() {
        return mWebTitle;
    }

    public String getUrl() {
        return mUrl;
    }
}
